- 313 nonlinear group
- Xiamen Uninversity
- How to run:
  1. Transfer the project folder to your ws_caric directory and unzip it.
  2. Transfer the project folder to your ws_caric directory and unzip it.
  3. run in terminal:
  ```bash
  cd ~/ws_caric
  catkin clean caric_competition_xmu # if you have build before
  catkin build caric_competition_xmu
  catkin build caric_competition_xmu # maybe failed, please try again in order to compile the msgs
  source devel/setup.bash
  cd src/caric_competition_xmu/src/inspector
  chmod +x get_points_in_faces.py
  roslaunch caric_competition_xmu xmu_launch_mbs.launch
  roslaunch caric_competition_xmu xmu_launch_hangar.launch
  roslaunch caric_competition_xmu xmu_launch_crane.launch
  ```
  4. you can also modify the `scenario` in these launch files in "caric_competition_xmu/launch/xmu_all/"

- something important
  1. in python file "caric_competition_xmu/src/inspector/get_points_in_faces.py", you may need to confirm the python path, we use "#!/usr/bin/python3" here. This is the same as "ppcom_router.py", "odom2tf.py" in caric_mission.
  2. 'chmod +x get_points_in_faces.py' is essential.
  3. the init step by the python file may comsume about 30 secends, and then the inspectors will take off.

- If there are any problems in compiling or running our code, please do not hesitate to contact us:
  - Bangwei Zhao (Discord or bangweizhao@stu.xmu.edu.cn)
  - Jiarui Guo (23220231151763@stu.xmu.edu.cn)
  - Xianglin Chen (chenxianglin22@qq.com)
  - Yiwei Zheng (ywzheng1201@stu.xmu.edu.cn)
- A more detailed modified version will be submitted before final deadline.
