#include <vector>
#include <iostream>
#include <queue> 
#include <Eigen/Dense>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <trajectory_msgs/MultiDOFJointTrajectory.h>
#include <std_msgs/Header.h>
#include <visualization_msgs/Marker.h>
#include <geometry_msgs/Point.h>
#include <ctime>
#include <ros/ros.h>
#include <thread>
#include "trajectory_generator.h"
#include "msg_pub.h"
#include <octomap/octomap.h>
#include <octomap_msgs/Octomap.h>
#include <octomap_msgs/conversions.h>
#include <octomap_ros/conversions.h>
#include <geometry_msgs/TwistStamped.h>
#include "inspector/communication.h"
#include <mutex>

// 定义 inspector 类，包括 grid_map、位置、姿态信息等
class Inspector {
public:
    int search_points_x_length; 
    int search_points_y_length;
    int search_points_z_length; 
    std::vector<Eigen::Vector3d> search_points;  // 搜索点集 vector
    std::vector<std::vector<std::vector<SearchPoint>>> search_points_array; // 搜索点集 array
    std::vector<SearchPoint> frontier_points;  // 边界点集
    GridMap grid_map;        // 栅格地图
    Eigen::Vector3d pos;            // 当前位置
    Eigen::Vector3d ori;            // 姿态
    Eigen::Vector3d gimbal_pos;
    Eigen::Vector3d gimbal_ori;
    Eigen::Vector3d linear_vel;
    Eigen::Vector3d angular_vel;
    SearchPoint target_point;
    Eigen::MatrixXd _polyCoeff;     // 位置多项式
    Eigen::MatrixXd _polyCoeff_vel; // 速度多项式
    Eigen::MatrixXd _polyCoeff_acc; // 加速度多项式
    Eigen::VectorXd _polyTime;      // 时间分配（每段）

    // 定义waypoint
    struct waypoint{
        Eigen::Vector3i idx;  // 格点坐标
        double cost;      // 从起点到该格点的总代价
        double heuristic; // 启发式函数的值
        waypoint* parent;  // 父节点
        double yaw = 0;
    };
    std::vector<waypoint*> waypoint_path;
    std::vector<waypoint*> simplified_waypoint_path;
    double epsilon = 2;  // A star 简化阈值
    bool is_init = false;
    bool is_new_tarjectory_generate = false;
    bool is_last_trajectory_finish = true;
    bool is_start = false;
    bool is_collision_detect = false;
    bool is_finish_mini_uav_task = false;
    double error_threshold = 2;  // 目标点到达阈值
    SearchPoint last_delete_frontier_point;
    // 离无人机起始点最近的search point
    SearchPoint closest_search_point;
    // 起飞点
    Eigen::Vector3d start_pos;
    std::string name;
    bool is_octomap_occupy_init = false;
    int range = 1; // 地图膨胀范围
    std::mutex mtx;
    Eigen::Vector3d partner_pos;
    int expand_size;
    int uav_id;
    std::vector<nav_msgs::Odometry> swarm_odom;
    std::vector<SearchPoint> frontier_points_copy;
    int dis_threshold = 10; //飞机能照到兴趣点的最远距离
    int curr_mini_id = 2;
    int step = 3;
    int inspect_threshold = 2;
    int curr_seg = 0;
    ros::Time start_t;
    Eigen::Vector3d gimbal_target;
    // 构造函数
    Inspector(std::string name,int x_length, int y_length, int z_length){
        // this->start_pos = start_pos;
        this->name=name;
        if(name=="jurong") uav_id=0;
        else if(name=="raffles") uav_id=1;
        this->search_points_x_length=x_length;
        this->search_points_y_length=y_length;
        this->search_points_z_length=z_length;
        std::cout<<search_points_x_length<<search_points_y_length<<search_points_z_length<<std::endl;
        this->swarm_odom=std::vector<nav_msgs::Odometry>(5);
    }

    //静态函数
    void init(double x_min,double x_max,double y_min,double y_max,double z_min,double z_max,
                double resolution,std::vector<Eigen::Vector3d> point_set)
                // double origin_x,double origin_y,double origin_z,)
    {
        grid_map=GridMap((x_max-x_min)/2+x_min, (y_max-y_min)/2+y_min, (z_max-z_min)/2+z_min, (x_max-x_min)+10, (y_max-y_min)+10, (z_max-z_min)+10, resolution);
                search_points=point_set;
    }

    void init_map(std::vector<Eigen::Vector3d>& point_set) {
        // 根据 bounding box 的范围建立地图，设置 all points in bbox 的点为占据状态
        
        // for bad point init
        for(auto point:point_set){
            grid_map.set_occupancy_pos(point,true);
        }

        init_search_array();

        // for bad point init
        // for(auto point:point_set){
        //     grid_map.set_occupancy_pos(point,false);
        // }
        // update_search_array();

        // int count=0;
        // for(int i=0;i<search_points_x_length;i++){
        //     for(int j=0;j<search_points_y_length;j++){
        //         for(int k=0;k<search_points_z_length;k++){
        //             if(!search_points_array[i][j][k].is_bad && !search_points_array[i][j][k].is_obstacle)count++;
        //         }
        //     }
        // }
        // std::cout<<count<<std::endl;

        
    } 

     void init_map_inbox(std::vector<Eigen::Vector3d>& point_set) {
        // 根据 bounding box 的范围建立地图，设置 all points in bbox 的点为占据状态
        
        // for bad point init
        int count=0;
        for(auto point:point_set){
            grid_map.set_occupancy_pos(point,true);
            count++;
        }
        //计算被占据的格点数量
        for(int i=0;i<grid_map.max_index(0);i++){
            for(int j=0;j<grid_map.max_index(1);j++){
                for(int k=0;k<grid_map.max_index(2);k++){
                    if(grid_map.grid_map[i][j][k].is_occupied)count++;
                }
            }
        }
        std::cout<<"ininbox point num: "<<count<<std::endl;
        // init_search_array();

        // for bad point init
        // for(auto point:point_set){
        //     grid_map.set_occupancy_pos(point,false);
        // }
        // update_search_array();

        // int count=0;
        // for(int i=0;i<search_points_x_length;i++){
        //     for(int j=0;j<search_points_y_length;j++){
        //         for(int k=0;k<search_points_z_length;k++){
        //             if(!search_points_array[i][j][k].is_bad && !search_points_array[i][j][k].is_obstacle)count++;
        //         }
        //     }
        // }
        // std::cout<<count<<std::endl;

        
    } 

    void init_search_array(){
        search_points_array.resize(search_points_x_length, std::vector<std::vector<SearchPoint>>(search_points_y_length,std::vector<SearchPoint>(search_points_z_length)));
        // search vector -> search array
        int count=0, obnum=0;
        for(int i=0;i<search_points_x_length;i++){
            for(int j=0;j<search_points_y_length;j++){
                for(int k=0;k<search_points_z_length;k++){
                    // 考虑是否为障碍
                    if(grid_map.get_occupancy_pos(search_points[count]))
                    {
                        search_points_array[i][j][k] = SearchPoint(search_points[count],i,j,k,true);
                        obnum++;
                    }
                    else search_points_array[i][j][k] = SearchPoint(search_points[count],i,j,k,false);
                    count++;
                }
            }
        }
        // 考虑是否离bbox太远
        for(int i=0;i<search_points_x_length;i++){
            for(int j=0;j<search_points_y_length;j++){
                for(int k=0;k<search_points_z_length;k++){
                    if(search_points_array[i][j][k].is_obstacle)continue;
                    bool neighbor = false;
                    int neighbor_num = 0;
                    // 遍历可能的相邻位置 26
                    for (int dx = -1; dx <= 1 && !neighbor; dx++) {
                        for (int dy = -1; dy <= 1 && !neighbor; dy++) {
                            for (int dz = -1; dz <= 1 && !neighbor; dz++) {
                                int newX = i + dx;
                                int newY = j + dy;
                                int newZ = k + dz;
                                // 检查是否越界 
                                if (newX >= 0 && newX < search_points_x_length && newY >= 0 && newY < search_points_y_length && newZ >= 0 && newZ < search_points_z_length) {
                                    if(search_points_array[newX][newY][newZ].is_obstacle){
                                        neighbor_num++;
                                        if(neighbor_num>=2)neighbor=true;
                                    }                     
                                }
                            }
                        }
                    }
                    // // 遍历可能的相邻位置 6
                    // std::vector<int> dxx = {0,0,0,0,1,-1};
                    // std::vector<int> dyy = {0,0,1,-1,0,0};
                    // std::vector<int> dzz = {1,-1,0,0,0,0};
                    // for (auto dx:dxx) {
                    //     for (auto dy:dyy) {
                    //         for (auto dz:dzz) {
                    //             int newX = i + dx;
                    //             int newY = j + dy;
                    //             int newZ = k + dz;
                    //             // 检查是否越界 
                    //             if (newX >= 0 && newX < search_points_x_length && newY >= 0 && newY < search_points_y_length && newZ >= 0 && newZ < search_points_z_length) {
                    //                 if(search_points_array[newX][newY][newZ].is_obstacle){
                    //                     neighbor=true;
                    //                 }                     
                    //             }
                    //         }
                    //     }
                    // }
                    search_points_array[i][j][k].is_bad=!neighbor;
                }
            }
        }
    }

    void update_search_array(){
        for(int i=0;i<search_points_x_length;i++){
            for(int j=0;j<search_points_y_length;j++){
                for(int k=0;k<search_points_z_length;k++){
                    // 考虑是否为障碍
                    if(grid_map.get_occupancy_pos(search_points_array[i][j][k].pos))
                        search_points_array[i][j][k].is_obstacle = true;
                    // else search_points_array[i][j][k].is_obstacle = true;
                }
            }
        }
    }

    void set_inpect_grid(std::vector<Eigen::Vector3d>& point_set){
        for(auto point:point_set){
            grid_map.set_need_to_inspect_pos(point,true);
        }
    }


    void gimbal_callback(const geometry_msgs::TwistStamped::ConstPtr &msg)
    {   try {
            gimbal_ori[0] = -msg->twist.linear.x;
            gimbal_ori[1] = -msg->twist.linear.y;
            gimbal_ori[2] = -msg->twist.linear.z;
        }
        catch (...) {
            std::cout << "[" + this->name + "]" << "gimbal_cb error !\t" << ros::Time::now() << std::endl;
        }
    }

    // 读取 odometry 数据 更新 inspector 的位置和姿态信息
    // 并判断是否到达 target point
    void odometry_callback(const nav_msgs::Odometry::ConstPtr& odom){
        try {
        update_state(*odom);
        update_map();
        update_search_array(); //更新search point是否被占用

        swarm_odom[uav_id].child_frame_id = odom->child_frame_id;
        swarm_odom[uav_id].header = odom->header;
        swarm_odom[uav_id].pose = odom->pose;
        swarm_odom[uav_id].twist = odom->twist;
        caric_competition_xmu::swarm_odom_pub.publish(caric_competition_xmu::swarm_odom2msg(swarm_odom));

        if(!is_init){ 
            // 起飞到正上空的一个较高的无碰撞点
            Eigen::Vector3d tmp =Eigen::Vector3d(pos[0],pos[1],grid_map.z_max);
            std::vector<Eigen::Vector3i>  tmp_points= ray_casting(pos,tmp);
            Eigen::Vector3d tmp_target = Eigen::Vector3d(grid_map.index2pos(tmp_points[0])[0],grid_map.index2pos(tmp_points[0])[1],grid_map.index2pos(tmp_points[0])[2] - 5);
            target_point = get_closest_search_point(tmp_target);
            ROS_INFO("[%s] First Target Point:(%f,%f,%f)",name.c_str(),target_point.pos[0],target_point.pos[1],target_point.pos[2]);
            struct waypoint start_waypoint, end_waypoint;
            grid_map.pos2index(pos,start_waypoint.idx);
            grid_map.pos2index(target_point.pos,end_waypoint.idx);
            waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);
            generate_trajetory(waypoint_path);
            is_init = true; 
        }
        else{
            // 避障
            if(is_collision_detect){ 
                frontier_points.push_back(last_delete_frontier_point);  // 因为没有到达目标 把之前删掉的边界点加回去
                struct waypoint start_waypoint, end_waypoint;
                grid_map.pos2index(pos,start_waypoint.idx);
                // first go to the closest point
                closest_search_point = get_closest_search_point(pos);
                grid_map.pos2index(closest_search_point.pos,end_waypoint.idx);
                waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);
                // if no way, back to the last point
                if(waypoint_path.size()==0){
                    grid_map.pos2index(target_point.pos,end_waypoint.idx);
                    waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);
                }
                else target_point = closest_search_point;
                ROS_INFO("[%s] Collision Avoid : Next Target Point:(%f,%f,%f)",name.c_str(),target_point.pos[0],target_point.pos[1],target_point.pos[2]);        
                generate_trajetory(waypoint_path);
                is_collision_detect = false;
            }
            else{
                double error = std::pow(std::pow(odom->pose.pose.position.x-target_point.pos[0],2)+
                    std::pow(odom->pose.pose.position.y-target_point.pos[1],2)+
                    std::pow(odom->pose.pose.position.z-target_point.pos[2],2),0.5);
                if(error < error_threshold && is_last_trajectory_finish){
                    update_frontier_points(target_point.x,target_point.y,target_point.z,frontier_points);
                    struct waypoint start_waypoint, end_waypoint;
                    grid_map.pos2index(target_point.pos,start_waypoint.idx); 
                    std::priority_queue<SearchPoint, std::vector<SearchPoint>, CompareSearchPoint> pq;
                    
                    pq=get_target_point(frontier_points, pos, ori); //优先队列 按优先级依次去找安全的目标
                                        
                    
                    //判断是否是空的
                    if(pq.size()==0){
                        ROS_WARN("[%s] no target point",name.c_str());
                        return;
                    }
                    target_point = pq.top();
                    pq.pop();
                    grid_map.pos2index(target_point.pos,end_waypoint.idx);
                    waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);
                    // 如果找不到一条合法的A*路径 换下一个目标
                    while(waypoint_path.size()==0 && pq.size()>0){
                        target_point = pq.top();
                        pq.pop();
                        grid_map.pos2index(target_point.pos,end_waypoint.idx);
                        waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);    
                    }
                    // 如果所有目标都找不到一条合法的A*路径 换之前删去的启发值很低的边界点
                    if(waypoint_path.size()==0 && pq.size()==0){
                        while(waypoint_path.size()==0 && frontier_points_copy.size()>0){
                            target_point = frontier_points_copy[0];
                            frontier_points_copy.erase(frontier_points_copy.begin()+0);
                            grid_map.pos2index(target_point.pos,end_waypoint.idx);
                            waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);    
                        }
                    }
                    // 极端情况 原始A*合法但是全部A*点作为trajetory仍然不合法 但其实分辨率1时A*已经非常紧密了
                    // 换次优目标点
                    while(!generate_trajetory(waypoint_path) && pq.size()>0){
                        target_point = pq.top();
                        pq.pop();
                        grid_map.pos2index(target_point.pos,end_waypoint.idx);
                        waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);
                    }
                    // 如果所有目标都找不到一条合法的trajetory 换之前删去的启发值很低的边界点
                    if(!generate_trajetory(waypoint_path) && pq.size()==0){
                        while(!generate_trajetory(waypoint_path) && frontier_points_copy.size()>0){
                            target_point = frontier_points_copy[0];
                            frontier_points_copy.erase(frontier_points_copy.begin()+0);
                            grid_map.pos2index(target_point.pos,end_waypoint.idx);
                            waypoint_path = AStar(start_waypoint,end_waypoint,grid_map);    
                        }
                    }
                    last_delete_frontier_point = target_point;
                    // 删掉边界点
                    for(int i=0;i<frontier_points.size();i++){
                        if(frontier_points[i].pos==target_point.pos){
                            frontier_points.erase(frontier_points.begin() + i);
                            break;
                        }
                    }
                    // 没救了 估计是lidar错误把无人机当前位置当作障碍了
                    if(pq.size()==0 && frontier_points_copy.size()==0 && waypoint_path.size()==0){
                        // if(uav_id==0) curr_mini_id=-1;
                        ROS_WARN("[%s] error, Lidar Treats the UAVs as error",name.c_str());  // added
                    } 
                    ROS_INFO("[%s] Next Target Point:(%f,%f,%f)",name.c_str(),target_point.pos[0],target_point.pos[1],target_point.pos[2]);         
                }
            }
        }
        }
        catch (...) {
            std::cout << "[" + this->name + "]" << "odom_cb error !\t" << ros::Time::now() << std::endl;
        }
    }

    // 计算点到直线的距离
    double pointToLineDistance(Eigen::Vector3d A, Eigen::Vector3d B, Eigen::Vector3d P) {
        // 计算向量 AB 和 AP
        double ABx = B[0] - A[0];
        double ABy = B[1] - A[1];
        double ABz = B[2] - A[2];

        double APx = P[0] - A[0];
        double APy = P[1] - A[1];
        double APz = P[2] - A[2];

        // 计算法向量 N
        double Nx = ABy * APz - ABz * APy;
        double Ny = ABz * APx - ABx * APz;
        double Nz = ABx * APy - ABy * APx;

        // 计算法向量 N 的模
        double N_length = std::sqrt(Nx * Nx + Ny * Ny + Nz * Nz);

        // 计算点到直线的距离
        double AB_length = std::sqrt(ABx * ABx + ABy * ABy + ABz * ABz);

        // 避免除以零的情况
        if (AB_length == 0.0) {
            throw std::invalid_argument("The length of line segment AB is zero.");
        }

        double distance = N_length / AB_length;

        return distance;
    }


    // 执行 Douglas-Peucker 算法 精简A* 不然中间点过多一卡一卡
    std::vector<waypoint *> douglasPeucker(std::vector<waypoint *> points, double epsilon) {
        std::vector<waypoint *> simplified;

        if (points.size() < 3) {
            return points;
        }

        // 寻找最远点
        double maxDistance = 0.0;
        size_t maxIndex = 0;

        waypoint * start = points.front();
        waypoint * end = points.back();

        for (size_t i = 1; i < points.size() - 1; ++i) {
            double d = pointToLineDistance(grid_map.index2pos(start->idx), grid_map.index2pos(end->idx), grid_map.index2pos(points[i]->idx));
            if (d > maxDistance) {
                maxDistance = d;
                maxIndex = i;
            }
        }

        // 如果最大距离大于阈值，则保留最远点，否则继续递归简化
        if (maxDistance > epsilon) {
            std::vector<waypoint *> firstPart(points.begin(), points.begin() + maxIndex + 1);
            std::vector<waypoint *> secondPart(points.begin() + maxIndex, points.end());
            std::vector<waypoint *> simplifiedFirst, simplifiedSecond;

            simplifiedFirst = douglasPeucker(firstPart, epsilon);
            simplifiedSecond = douglasPeucker(secondPart, epsilon);

            simplified.insert(simplified.end(), simplifiedFirst.begin(), simplifiedFirst.end() - 1);
            simplified.insert(simplified.end(), simplifiedSecond.begin(), simplifiedSecond.end());
        } else {
            simplified.clear();
            simplified.push_back(start);
            simplified.push_back(end);
        }
        return simplified;
    }

    bool generate_trajetory(std::vector<waypoint *> waypoints){
        if(waypoints.size()==0){
            ROS_INFO("[%s] error!  A* waypoints is empty",name.c_str());   
            return false;      
        }
        // 当前点即为目标点
        if(waypoints.size()==1){
            waypoints.push_back(waypoints[0]);
        }
        // 简化A*路点
        try{
            simplified_waypoint_path = douglasPeucker(waypoints,epsilon);
        }catch (const std::invalid_argument& e) {
            std::cerr << "Error: " << e.what() << std::endl;
        }
        // // 两个点的直线snap也能跑歪 
        // if(simplified_waypoint_path.size()==2){
        //     waypoint* tmp = new waypoint;
        //     tmp->idx = (simplified_waypoint_path[0]->idx + simplified_waypoint_path[1]->idx)/2; 
        //     simplified_waypoint_path.insert(simplified_waypoint_path.begin() + 1, tmp);
        // }
        Eigen::MatrixXd waypoint_path_matrix(simplified_waypoint_path.size(), 3); 
        for(int k = 0; k < simplified_waypoint_path.size(); k++){
            waypoint_path_matrix.row(k) = Eigen::Vector3d(grid_map.index2pos(simplified_waypoint_path[k]->idx)[0],
                                                        grid_map.index2pos(simplified_waypoint_path[k]->idx)[1],
                                                        std::max(0.2,grid_map.index2pos(simplified_waypoint_path[k]->idx)[2]));
        }
        trajGeneration(waypoint_path_matrix,_polyCoeff,_polyTime);
        std::vector<waypoint *> correct_waypoint_path = correct_trajectory();
        // 如果traj不合法 尝试去对精简后的A*路点集添加原来的路点来使traj更贴近原始A*路点的轨迹
        while(correct_waypoint_path.size()!=0){
            // 即便是原始A*路点也不行 那就放弃这个目标
            if(simplified_waypoint_path.size()==correct_waypoint_path.size()){
                ROS_INFO("[%s] can not find safe trajectory",name.c_str());  
                return false;
            }
            simplified_waypoint_path=correct_waypoint_path;
            waypoint_path_matrix = Eigen::MatrixXd(simplified_waypoint_path.size(), 3); 
            for(int k = 0; k < simplified_waypoint_path.size(); k++){
            waypoint_path_matrix.row(k) = Eigen::Vector3d(grid_map.index2pos(simplified_waypoint_path[k]->idx)[0],
                                                        grid_map.index2pos(simplified_waypoint_path[k]->idx)[1],
                                                        std::max(0.2,grid_map.index2pos(simplified_waypoint_path[k]->idx)[2]));
            }
            trajGeneration(waypoint_path_matrix,_polyCoeff,_polyTime);
            std::vector<waypoint *> correct_waypoint_path = correct_trajectory();
        }

        _polyCoeff_vel = calculate_polycoeff_de(_polyCoeff);
        _polyCoeff_acc = calculate_polycoeff_de(_polyCoeff_vel);
        is_new_tarjectory_generate = true;
        return true;
    }

    // 找到trajectory不安全的首个点距离精简前的waypoints中最近的那一个 然后加进去
    std::vector<waypoint *> correct_trajectory(){
        Eigen::Vector3d unsafe_point;
        waypoint * add_point;
        std::vector<waypoint *> added_path;
        bool already_in = false;
        for(int i=0;i<_polyTime.size();i++){
            for(double t=0;t<=_polyTime[i];t+=0.1){
                unsafe_point = getPosPoly(_polyCoeff,i,t);
                if(grid_map.get_occupancy_pos(unsafe_point)){
                    std::cout<<"trajectory unsafe" << std::endl;
                    if(simplified_waypoint_path.size()==waypoint_path.size()){
                        std::cout<<"simplified_waypoint_path have alread become waypoint_path" << std::endl;
                    }
                    double min_dis = DBL_MAX;
                    for(auto waypoint:waypoint_path){
                        double tmp = (grid_map.index2pos(waypoint->idx)-unsafe_point).norm();
                        if(tmp<min_dis){
                            for(auto s_waypoint:simplified_waypoint_path){
                                if(waypoint->idx==s_waypoint->idx){
                                    already_in = true;
                                    break;
                                }
                            }
                            if(already_in){
                                already_in = false;
                                continue;
                            }
                            min_dis = tmp;
                            add_point = waypoint;
                        }
                    }
                    // 保证顺序
                    for(auto waypoint:waypoint_path){
                        for(auto s_waypoint:simplified_waypoint_path){
                            if(waypoint->idx==s_waypoint->idx){
                                added_path.push_back(waypoint);
                                break;
                            }
                        }
                        if(waypoint->idx == add_point->idx) added_path.push_back(waypoint);
                            
                    }
                    return added_path;
                }
            }
        }
        return added_path;
    }

    void update_state(nav_msgs::Odometry odom){
        // 更新位置和姿态信息
        pos[0]=odom.pose.pose.position.x;
        pos[1]=odom.pose.pose.position.y;
        pos[2]=odom.pose.pose.position.z;

        tf::Quaternion quat;
        double roll, pitch, yaw;//定义存储r\p\y的容器
        // tf::quaternionMsgToTF(odom.pose.pose.orientation, quat);
        // tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);
        Eigen::Quaterniond q(odom.pose.pose.orientation.w, odom.pose.pose.orientation.x, odom.pose.pose.orientation.y, odom.pose.pose.orientation.z);
        ori=Eigen::Quaterniond(q.w(),q.x(),q.y(),q.z()).toRotationMatrix().eulerAngles(2,1,0);
        // ori[0] = -roll;
        // ori[1] = -pitch;
        // ori[2] = -yaw;               // Added TODO 这个注意一下, 记得确认

        linear_vel = Eigen::Vector3d(odom.twist.twist.linear.x,odom.twist.twist.linear.y,odom.twist.twist.linear.z);
        angular_vel = Eigen::Vector3d(odom.twist.twist.angular.x,odom.twist.twist.angular.y,odom.twist.twist.angular.z);
    }

    // 找到最近的一个search point
    SearchPoint get_closest_search_point(Eigen::Vector3d _pos){
        SearchPoint tmp_point;
        double distance = 100000000;
        for(int i=0;i<search_points_x_length;i++){
            for(int j=0;j<search_points_y_length;j++){
                for(int k=0;k<search_points_z_length;k++){
                    // 考虑是否为障碍
                    if(!grid_map.get_occupancy_pos(search_points_array[i][j][k].pos)){
                        double tmp = std::pow(std::pow(_pos[0]-search_points_array[i][j][k].pos[0],2)+
                                    std::pow(_pos[1]-search_points_array[i][j][k].pos[1],2)+
                                    std::pow(_pos[2]-search_points_array[i][j][k].pos[2],2),0.5);
                        if(tmp<distance){
                            distance=tmp;
                            tmp_point = search_points_array[i][j][k];
                        }
                    }
                }
            }
        }
        return tmp_point;
    }

    std::vector<Eigen::Vector3i> ray_casting(Eigen::Vector3d& position,Eigen::Vector3d& target_position){
        // 判断两点之间是否存在遮挡
        // 先来简单版本，不考虑姿态
        std::vector<Eigen::Vector3i> idxs;
        int num_slides=((target_position-position).norm()/grid_map.resolution+1);
        Eigen::Vector3d middle_position;
        for(double a=1.0/num_slides;a<1.0-1.0/num_slides;a+=1.0/num_slides){
            middle_position=position+a*(target_position-position);
            Eigen::Vector3i idx;
            auto re=grid_map.pos2index(middle_position,idx);
            if(!re)//如果索引不合法,false(默认空)
            {
                continue;
            }
            if(grid_map.grid_map[idx[0]][idx[1]][idx[2]].is_occupied==true)
            {
                idxs.push_back(idx);
            }
        }
        return idxs;
    }

    bool have_collision(Eigen::Vector3d& position,Eigen::Vector3d& target_position){
        // auto re=ray_casting(position,target_position);
        // if(re.size()>0)
        //     return true;
        // else
        //     return false;
        return false; //暂时不考虑遮挡
    }


    // 获取能被检测到的未被检测过的点的索引
    // step 跳点 dis_thres 距离阈值
    std::vector<Eigen::Vector3i> get_covered_points(Eigen::Vector3d& position, Eigen::Vector3d& orientation) {
        // 根据当前的位置和姿态获取能被检测到的未被检测过的点
        //先来简单版本，不考虑姿态
        Eigen::Vector3i idx;
        auto re=grid_map.pos2index(position,idx);
        //我就在这个idx附近找一圈
        int x_min=idx[0]-dis_threshold;//这里改成10但是下面step从1改成2 因为其实不需要精确的知道点的数量 只要有一个大概的数量就行
        int x_max=idx[0]+dis_threshold;
        int y_min=idx[1]-dis_threshold;
        int y_max=idx[1]+dis_threshold;
        int z_min=idx[2]-dis_threshold;
        int z_max=idx[2]+dis_threshold;
        std::vector<Eigen::Vector3i> idxs;
        for(int i=std::max(0,x_min);i<std::min(x_max,grid_map.max_index[0]);i+=step){
            for(int j=std::max(0,y_min);j<std::min(y_max,grid_map.max_index[1]);j+=step){
                for(int k=std::max(0,z_min);k<std::min(z_max,grid_map.max_index[2]);k+=step){
                    auto target_position=grid_map.index2pos(Eigen::Vector3i(i,j,k));
                    if(!have_collision(position,target_position))
                    {
                        if(grid_map.grid_map[i][j][k].need_to_inspect==true&&grid_map.grid_map[i][j][k].is_inspected<inspect_threshold)
                        {
                            Eigen::Vector3i idx(i,j,k);
                            idxs.push_back(idx);
                        }
                    }
                }
            }
        }
        
        return idxs;
    }
    
    inline double my_norm_w_alt(Eigen::Vector3d pos_1, Eigen::Vector3d pos_2) {
        double cost_factor_xy = 1;
        double cost_factor_z  = 0.25;           // 可以调整

        if (pos_1[2] >= pos_2[2]) {
            cost_factor_z = 0.65;               // default: 0.25 可以是负的, 但是设计成负值可能导致一直往高了飞
        } else {
            cost_factor_z = 0.65;               // default: 1.25
        }

        double dx = pos_1[0] - pos_2[0];
        double dy = pos_1[1] - pos_2[1];
        double dz = pos_1[2] - pos_2[2];

        return std::sqrt(cost_factor_xy * (dx * dx + dy * dy) + cost_factor_z * dz * dz);    
    }

    // 获取启发式值
    double get_heuristic(Eigen::Vector3d& position, Eigen::Vector3d& orientation, Eigen::Vector3d new_point) {
        // 遍历关键点，综合考虑距离和新观测量，获取前往的目标点
        std::vector<Eigen::Vector3i> idxs = get_covered_points(new_point,orientation);
        int num_covered = 0;
        if(!idxs.empty()) num_covered=idxs.size();

        double distance;
        //distance = (new_point-position).norm();
        distance = my_norm_w_alt(new_point, position);      // 注意这个顺序不能反

        if(num_covered==0) return - INT16_MAX;
        else{
            return (   1 * -1.0 / (num_covered + 1)) 
                    + 75 * (1.0 / (distance + 1)) 
                    + 75 * (-1.0 / ((partner_pos - pos).norm() + 1));
            //      1   -1.0                        50    1.0                     50    -1.0            default value
        }
    }

    struct CompareSearchPoint {
        bool operator()(const SearchPoint& point1, const SearchPoint& point2) {
            return point1.heuristic < point2.heuristic;
        }
    };

    std::priority_queue<SearchPoint, std::vector<SearchPoint>, CompareSearchPoint> get_target_point(std::vector<SearchPoint>& frontier_points, Eigen::Vector3d curr_pos, Eigen::Vector3d curr_ori) {
        std::priority_queue<SearchPoint, std::vector<SearchPoint>, CompareSearchPoint> pq;
        frontier_points_copy.clear();
        time_t t0 = time(nullptr);
        // 将所有前沿点加入优先队列
        for (int i=0;i<frontier_points.size();i++) {
            frontier_points[i].heuristic = get_heuristic(curr_pos, curr_ori, frontier_points[i].pos);
            // 如果边界点周围没有可检测的点，删除它，并将其加入到备选边界点中
            if(frontier_points[i].heuristic == -INT16_MAX){ 
                frontier_points_copy.push_back(frontier_points[i]);
                frontier_points.erase(frontier_points.begin()+i);
                continue;
            }
            pq.push(frontier_points[i]);
            if(time(nullptr)-t0>5) break;
        }
        if(pq.size()==0){
            pq.push(frontier_points[0]);
        }

        // // 获取优先队列中的顶部元素，即具有最大启发式值的点
        // SearchPoint target_point = pq.top();

        // // 如果不是预测，记录上一次删除的点
        // if (!is_predict) {
        //     last_delete_frontier_point = target_point;
        // }

        // // 从前沿点中移除该点
        // frontier_points.erase(std::remove(frontier_points.begin(), frontier_points.end(), target_point), frontier_points.end());

        return pq;
    }

    // 更新边界点集合
    void update_frontier_points(int x,int y,int z, std::vector<SearchPoint>& frontier_points){
        search_points_array[x][y][z].is_visited = true;
        search_points_array[x][y][z].is_in_frontier = false;

        // 遍历可能的相邻位置
        int range = 2;
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    int newX = x + dx;
                    int newY = y + dy;
                    int newZ = z + dz;

                    // 检查是否越界
                    if (newX >= 0 && newX < search_points_x_length && newY >= 0 && newY < search_points_y_length && newZ >= 0 && newZ < search_points_z_length) {
                        // 如果相邻点不是障碍 or bad point、边界点以及没有被访问，将其加入边界队列
                        if (!search_points_array[newX][newY][newZ].is_in_frontier && !search_points_array[newX][newY][newZ].is_obstacle && !search_points_array[newX][newY][newZ].is_bad && !search_points_array[newX][newY][newZ].is_visited) {
                            search_points_array[newX][newY][newZ].is_in_frontier=true;
                            frontier_points.push_back(search_points_array[newX][newY][newZ]);        
                        }
                    }
                }
            }
        }
    }


    // 比较两个节点的总代价
    struct CompareWaypoint {
        bool operator()(const waypoint* a, const waypoint* b) const {
            return (a->cost + a->heuristic) > (b->cost + b->heuristic);
        }
    };

    std::vector<waypoint*> AStar(waypoint& start, waypoint& goal, GridMap map) {
        std::vector<waypoint*> path;

        // 定义移动方向
        const int dx[] = {1, 1, 1, 0, 0, 0, -1, -1, -1, 1, 1, 1, 0,  0, -1, -1, -1, 1, 1, 1, 0, 0, 0, -1, -1, -1};
        const int dy[] = {1, 0, -1, 1, 0, -1, 1, 0, -1, 1, 0, -1, 1,  -1, 1, 0, -1, 1, 0, -1, 1, 0, -1, 1, 0, -1};
        const int dz[] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,  0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1};

        const int x_length = map.max_index[0];
        const int y_length = map.max_index[1];
        const int z_length = map.max_index[2];

        // 创建数组来记录节点是否已经被访问
        std::vector<std::vector<std::vector<bool>>> visited(x_length, std::vector<std::vector<bool>>(y_length, std::vector<bool>(z_length, false)));

        // 创建数组来记录节点是否已经被add
        std::vector<std::vector<std::vector<bool>>> added(x_length, std::vector<std::vector<bool>>(y_length, std::vector<bool>(z_length, false)));

        // 创建优先队列用于节点扩展
        std::priority_queue<waypoint*, std::vector<waypoint*>, CompareWaypoint> openSet;

        // 初始化起始节点
        waypoint* startNode = new  waypoint{start.idx, 0, 0, nullptr};
        openSet.push(startNode);
        added[start.idx[0]][start.idx[1]][start.idx[2]] = true;

        if(start.idx==goal.idx){
            path.push_back(startNode);
            return path;
        }

        while (!openSet.empty()) {
            // 从优先队列中取出代价最小的节点
            waypoint* current = openSet.top();
            openSet.pop();

            // 如果当前节点是目标节点，构建并返回路径
            if (current->idx[0] == goal.idx[0] && current->idx[1] == goal.idx[1] && current->idx[2] == goal.idx[2]) {
                
                while (current != nullptr) {
                    path.push_back(current);
                    current = current->parent;
                }
                std::reverse(path.begin(),path.end());
                return path;
            }            
            visited[current->idx[0]][current->idx[1]][current->idx[2]] = true;

            // 扩展当前节点
            for (int i = 0; i < 26; i++) {
                int nextX = current->idx[0] + dx[i];
                int nextY = current->idx[1] + dy[i];
                int nextZ = current->idx[2] + dz[i];
                Eigen::Vector3i nextWaypoint(nextX,nextY,nextZ);

                // 检查是否越界或者是障碍物
                if (nextX < 0 || nextX >= x_length || nextY < 0 || nextY >= y_length || nextZ < 0 || nextZ >= z_length || map.get_occupancy_idx(nextWaypoint))
                    continue;

                // 如果节点已经访问过 or added，跳过
                if (visited[nextX][nextY][nextZ] || added[nextX][nextY][nextZ])
                    continue;

                // 计算下一个节点的代价和启发式函数值
                double nextCost = current->cost + std::pow(std::pow(nextX - current->idx[0],2) + std::pow(nextY - current->idx[1],2) + std::pow(nextZ - current->idx[2],2),0.5); 
                double heuristic = std::pow(std::pow(nextX - goal.idx[0],2) + std::pow(nextY - goal.idx[1],2) + std::pow(nextZ - goal.idx[2],2),0.5); 
                // 创建下一个节点
                waypoint* nextNode = new waypoint{nextWaypoint, nextCost, heuristic, current};

                openSet.push(nextNode);
                added[nextX][nextY][nextZ] = true;
            }
        }

        // // 如果无法找到路径，返回一个空路径
        ROS_INFO("[%s]A* can not find valid waypoints to reach target!", name.c_str());
        return std::vector<waypoint*>();
    }
    // zbw
    bool in_sight(Eigen::Vector3d photo_point){
        tf::Matrix3x3 world2uav, uav2camera;
        tf::Vector3 target_point(photo_point[0],photo_point[1],photo_point[2]);

        world2uav.setRPY(ori[0], ori[1], ori[2]);
        uav2camera.setRPY(gimbal_ori[0],gimbal_ori[1],gimbal_ori[2]);
        tf::Vector3 tf_target_dir = uav2camera * world2uav * target_point;
        
        // Eigen::Vector3d target_dir = photo_point-gimbal_pos;
        Eigen::Vector3d curr_dir(1,0,0); 
        Eigen::Vector3d target_dir(tf_target_dir[0],tf_target_dir[1],tf_target_dir[2]);
        double angle = acos((target_dir.dot(curr_dir))/(target_dir.norm()*curr_dir.norm()));
        
        return (angle/M_PI*180) < 30;
    }

    // 更新地图状态
    // dis_thres
    void update_map() {
        // 根据当前的位置和姿态，更新地图，设置点状态为已检测
        Eigen::Vector3i idx;
        auto re = grid_map.pos2index(pos,idx);
        //我就在这个idx附近找一圈
        int x_min=idx[0]-dis_threshold;
        int x_max=idx[0]+dis_threshold;
        int y_min=idx[1]-dis_threshold;
        int y_max=idx[1]+dis_threshold;
        int z_min=idx[2]-dis_threshold;
        int z_max=idx[2]+dis_threshold;
        for(int i=std::max(0,x_min);i<std::min(x_max,grid_map.max_index[0]);i++){
            for(int j=std::max(0,y_min);j<std::min(y_max,grid_map.max_index[1]);j++){
                for(int k=std::max(0,z_min);k<std::min(z_max,grid_map.max_index[2]);k++){
                    if(grid_map.grid_map[i][j][k].is_inspected<inspect_threshold && grid_map.grid_map[i][j][k].need_to_inspect)
                    {   
                        auto target_pos=grid_map.index2pos(Eigen::Vector3i(i,j,k));
                        if(!have_collision(pos,target_pos) && in_sight(target_pos-pos))
                        {
                            grid_map.grid_map[i][j][k].is_inspected++;
                        }
                    }
                }
            }
        }
    }


    // 找到最近的无遮挡的未被检测的点的质心
    // 要考虑远近 越近权重越高 不然一直往前看而不看近的
    // step 跳点 dis_thres
    Eigen::Vector3d find_inspect_points_center(){
        Eigen::Vector3i idx;
        auto re=grid_map.pos2index(pos,idx);
        //我就在这个idx附近找一圈
        int x_min=idx[0]-dis_threshold;
        int x_max=idx[0]+dis_threshold;
        int y_min=idx[1]-dis_threshold;
        int y_max=idx[1]+dis_threshold;
        int z_min=idx[2]-dis_threshold;
        int z_max=idx[2]+dis_threshold;
        std::vector<Eigen::Vector3d> points;
        Eigen::Vector3d points_center;
        for(int i=std::max(0,x_min);i<std::min(x_max,grid_map.max_index[0]);i+=step){
            for(int j=std::max(0,y_min);j<std::min(y_max,grid_map.max_index[1]);j+=step){
                for(int k=std::max(0,z_min);k<std::min(z_max,grid_map.max_index[2]);k+=step){
                    auto target_pos=grid_map.index2pos(Eigen::Vector3i(i,j,k));
                    if(grid_map.grid_map[i][j][k].need_to_inspect&& grid_map.grid_map[i][j][k].is_inspected<inspect_threshold)
                    {
                        if(!have_collision(pos,target_pos)){
                            points.push_back(target_pos);
                        }
                        
                    }
                }
            }
        }
        Eigen::Vector3d  sum;
        for(auto point:points){
            sum+=point;
        }
        if(points.size()>0) points_center=sum/points.size();
        else points_center = Eigen::Vector3d(-1,-1,-1);
        this->gimbal_target = points_center;
        return points_center;

    }

    double saturation(double num,double max,double min){
        if(num>max)
            num=num-max;
        else if(num<min)
            num=num-min;
        return num;
    }

    double cal_desired_yaw(Eigen::Vector3d photo_point){
        photo_point<<photo_point.x(),photo_point.y(),pos[2];//投影到这个平面
        //计算两个向量的yaw
        //1.判断目标相对无人机在哪个象限
        Eigen::Vector3d target_dir = photo_point - pos;
        
        double yaw_dir;
        int phase_index=0;
        if(target_dir.x()>=0 && target_dir.y()>=0){
            yaw_dir=atan2(target_dir.y(),target_dir.x());
            phase_index=1;
            yaw_dir=yaw_dir;
        }
        else if(target_dir.x()<0 && target_dir.y()>0){
            yaw_dir=atan2(target_dir.y(),-target_dir.x());
            phase_index=2;
            yaw_dir=M_PI-yaw_dir;
        }   
        else if(target_dir.x()<=0 && target_dir.y()<=0){
            yaw_dir=atan2(-target_dir.y(),-target_dir.x());
            phase_index=3;
            yaw_dir=-M_PI+yaw_dir;
        }
        else{
            yaw_dir=atan2(-target_dir.y(),target_dir.x());
            phase_index=4;
            yaw_dir=-yaw_dir;
        }
        // yaw_dir=saturation(yaw_dir,M_PI,-M_PI);
        double uav_yaw=ori[2];
        // int uav_phase_index=0;
        // if(uav_yaw>=0 && uav_yaw<=M_PI/2){
        //     uav_phase_index=1;
        // }
        // else if(uav_yaw>M_PI/2 && uav_yaw<=M_PI){
        //     uav_phase_index=2;
        // }
        // else if(uav_yaw>-M_PI && uav_yaw<=-M_PI/2){
        //     uav_phase_index=3;
        // }
        // else{
        //     uav_phase_index=4;
        // }

        double desired_yaw;
        double yaw_diff=uav_yaw-yaw_dir;
        yaw_diff=saturation(yaw_diff,M_PI,-M_PI);
        // if(saturation(uav_yaw+yaw_diff,M_PI/2,-M_PI/2)==yaw_dir){
        //     desired_yaw=yaw_diff;
        // }
        // else{
        //     desired_yaw=-yaw_diff;
        // }
        if(uav_yaw>yaw_dir){
            if(yaw_diff>M_PI){
                desired_yaw=2*M_PI-yaw_diff;
            }
            else{
                desired_yaw=-yaw_diff;
            }
        }
        else{
            if(abs(yaw_diff)>M_PI){
                desired_yaw=-2*M_PI+yaw_diff;
            }
            else{
                desired_yaw=-yaw_diff;
            }
        }
        return desired_yaw;
    }

    double cal_desired_pitch(Eigen::Vector3d photo_point){
        Eigen::Vector3d pos_diff=photo_point-pos;
        double z_diff=pos_diff.z();
        double xy_diff=sqrt(pow(pos_diff.x(),2)+pow(pos_diff.y(),2));
        double desired_pitch;
        if(z_diff<0){//因为逆时针为正
            desired_pitch=atan2(-z_diff,xy_diff);
        }
        else{
            desired_pitch=-atan2(z_diff,xy_diff);
        }
        return desired_pitch;
    }

    void world_octomap_callback(const octomap_msgs::Octomap::ConstPtr &msg)
    {
        try {
            std::thread t2(std::bind(&Inspector::update_occupy,this,msg));
            t2.detach();
        }
        catch (...) {
            std::cout << "[" + this->name + "]" << "world_octomap_cb error !\t" << ros::Time::now() << std::endl;
        }

        // // Added
        // caric_competition_xmu::GridMapMsg grid_map_msg = caric_competition_xmu::map2msg(this->grid_map, this->name);
        // caric_competition_xmu::map_msg_pub.publish(grid_map_msg);
        // std::cout << "[" + this->name + "]" << "published Grid Map !\t" << ros::Time::now() << std::endl;        
    }

    void update_occupy(const octomap_msgs::Octomap::ConstPtr &msg){
        //根据获取的octomap更新grid_map
        int count=0;
        octomap::AbstractOcTree *tree = octomap_msgs::msgToMap(*msg);
        if (tree) {
            octomap::OcTree* octree = dynamic_cast<octomap::OcTree*>(tree);
            if (octree) {
                // 防止一开始没有点 全当成孤立点
                if(!is_octomap_occupy_init){
                    // 防止一开始没有点全当成孤立点
                    for (octomap::OcTree::iterator it = octree->begin(); it != octree->end(); ++it) {
                        // 不管越界
                        if(it.getCoordinate().x()<grid_map.x_min 
                            || it.getCoordinate().x()>grid_map.x_max
                            || it.getCoordinate().y()<grid_map.y_min 
                            || it.getCoordinate().y()>grid_map.y_max 
                            || it.getCoordinate().z()>grid_map.z_max
                            || it.getCoordinate().z()<0) continue;
                        grid_map.set_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z()), true);
                    }
                    for (octomap::OcTree::iterator it = octree->begin(); it != octree->end(); ++it) {
                        // 不管越界
                        if( it.getCoordinate().x()<grid_map.x_min 
                            || it.getCoordinate().x()>grid_map.x_max
                            || it.getCoordinate().y()<grid_map.y_min 
                            || it.getCoordinate().y()>grid_map.y_max 
                            || it.getCoordinate().z()>grid_map.z_max
                            || it.getCoordinate().z()<0) continue;
                        if(octree->isNodeOccupied(*it) && (grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z()+1)) ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z()-1))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y()+1, it.getCoordinate().z()))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y()-1, it.getCoordinate().z()))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x()+1, it.getCoordinate().y(), it.getCoordinate().z()))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x()-1, it.getCoordinate().y(), it.getCoordinate().z())))){
                            // 膨胀
                            for(int i=-range;i<=range;i++){
                                for(int j=-range;j<=range;j++){
                                    for(int k=-range;k<=range;k++){
                                        Eigen::Vector3d position(it.getCoordinate().x()+i, it.getCoordinate().y()+j, it.getCoordinate().z()+k);
                                        grid_map.set_occupancy_pos(position, true);
                                    }
                                }
                            }
                        }
                        else grid_map.set_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z()), false);
                    }

                    is_octomap_occupy_init = true;
                }
                else{
                    for (octomap::OcTree::iterator it = octree->begin(); it != octree->end(); ++it) {
                        // 不管越界
                        if(it.getCoordinate().x()<grid_map.x_min 
                            || it.getCoordinate().x()>grid_map.x_max
                            || it.getCoordinate().y()<grid_map.y_min 
                            || it.getCoordinate().y()>grid_map.y_max 
                            || it.getCoordinate().z()>grid_map.z_max) continue;
                        // 排除孤立点
                        if((grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z()+1)) ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z()-1))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y()+1, it.getCoordinate().z()))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x(), it.getCoordinate().y()-1, it.getCoordinate().z()))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x()+1, it.getCoordinate().y(), it.getCoordinate().z()))  ||
                        grid_map.get_occupancy_pos(Eigen::Vector3d(it.getCoordinate().x()-1, it.getCoordinate().y(), it.getCoordinate().z())))){
                        }
                        else{
                            Eigen::Vector3d position(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z());
                            grid_map.set_occupancy_pos(position, false);
                            continue;
                        }
                        if (octree->isNodeOccupied(*it)) {
                            // 膨胀
                            for(int i=-range;i<=range;i++){
                                for(int j=-range;j<=range;j++){
                                    for(int k=-range;k<=range;k++){
                                        Eigen::Vector3d position(it.getCoordinate().x()+i, it.getCoordinate().y()+j, it.getCoordinate().z()+k);
                                        // 不管地面
                                        if(position[2]<0) continue;
                                        grid_map.set_occupancy_pos(position, true);
                                    }
                                }
                            }
                        }
                        else {
                            Eigen::Vector3d position(it.getCoordinate().x(), it.getCoordinate().y(), it.getCoordinate().z());
                            grid_map.set_occupancy_pos(position, false);
                            count++;
                        }
                    }

                }
            } 
            else {
                ROS_ERROR("Failed to cast the abstract tree to OcTree.");
            }
        } 
        else {
            ROS_ERROR("Received an unsupported octomap type.");
        }
        ROS_INFO("[%s]update map %d points",name.c_str(),count);
    }

    // 用于显示waypoints
    void get_waypoints(visualization_msgs::Marker* marker){
        for(auto point:simplified_waypoint_path){
            geometry_msgs::Point p;
            Eigen::Vector3d pos = grid_map.index2pos(point->idx);
            p.x=pos[0];
            p.y=pos[1];
            p.z=pos[2];
            marker->points.push_back(p);
        }
    }

    // rviz marker显示
    void create_marker(visualization_msgs::Marker* marker,std::string frame_id, std::string ns,int32_t id,int32_t type,int32_t action, 
        double w, double x,double y,double z,double r,double g, double b, double a ){
        marker->header.frame_id = frame_id; // 设置坐标系
        marker->header.stamp = ros::Time::now();
        marker->ns = ns;
        marker->id = id;
        marker->type = type;
        marker->action = action;
        marker->pose.orientation.w = w;


        // 设置点的大小,三维点
        marker->scale.x = x;
        marker->scale.y = y;
        marker->scale.z = z;

        // 设置点的颜色
        marker->color.r = r;
        marker->color.g = g;
        marker->color.b = b;
        marker->color.a = a;
    }

    // 5
    void publish_marker(std::vector<visualization_msgs::Marker*> marker_list, ros::Publisher marker_pub){
        if(is_init){
            std::lock_guard<std::mutex> lock(mtx); //线程互斥锁
            for(auto marker:marker_list){
                // // 清空 Marker 消息的点
                marker->points.clear();
                if(marker->ns == "search_map_1"){
                    Inspector::get_occupied_points(*marker);
                } 
                else if(marker->ns == "search_map_4"){
                    geometry_msgs::Point p;
                    p.x=target_point.pos(0);
                    p.y=target_point.pos(1);
                    p.z=target_point.pos(2);
                    marker->points.push_back(p);

                }
                else if(marker->ns == "search_map_6") {
                    get_waypoints(marker);
                }
                // if(marker->ns == "search_map_7") Inspector::get_occupied_points(*marker);
                else if(marker->ns == "search_map_8"){
                    get_trajectory(*marker);
                }
                else if(marker->ns == "search_map_5"){
                    get_search_points(*marker);
                }
                else if(marker->ns =="search_map_2"){
                    get_inspected_points(*marker);
                }
                else if(marker->ns =="search_map_3"){
                    get_uninspected_points(*marker);
                }
                else if(marker->ns=="search_map_9"){
                    get_frontier_points(*marker);
                }
                else if(marker->ns=="search_map_10"){
                    get_gimbal_target(*marker);
                }
                marker_pub.publish(*marker); 
            }
            // Inspector::get_occupied_points(marker_occupied);
            // inspector.get_uninspected_points(marker_not_inspected);        
            // Inspector::get_inspected_points(marker_inspected);
            
        }
    }

    void get_gimbal_target(visualization_msgs::Marker& marker){
        geometry_msgs::Point p;
        p.x=gimbal_target.x();
        p.y=gimbal_target.y();
        p.z=gimbal_target.z();
        marker.points.push_back(p);
    }

    void get_frontier_points(visualization_msgs::Marker& marker){
        for(auto point:this->frontier_points){
            geometry_msgs::Point p;
            p.x=point.pos.x();
            p.y=point.pos.y();
            p.z=point.pos.z();
            marker.points.push_back(p);
        }
    }

    void get_occupied_points(visualization_msgs::Marker& marker){
        for(int i=0;i<grid_map.max_index[0];i++){
            for(int j=0;j<grid_map.max_index[1];j++){
                for(int k=0;k<grid_map.max_index[2];k++){
                    if(grid_map.grid_map[i][j][k].is_occupied==true )
                    {
                        Eigen::Vector3d pos=grid_map.index2pos(Eigen::Vector3i(i,j,k));
                        geometry_msgs::Point p;
                        p.x=pos[0];
                        p.y=pos[1];
                        p.z=pos[2];
                        marker.points.push_back(p);
                    }
                }
            }
        }
    }

    void get_uninspected_points(visualization_msgs::Marker& marker){
        for(int i=0;i<grid_map.max_index[0];i++){
            for(int j=0;j<grid_map.max_index[1];j++){
                for(int k=0;k<grid_map.max_index[2];k++){
                    if(grid_map.grid_map[i][j][k].is_inspected < inspect_threshold && grid_map.grid_map[i][j][k].need_to_inspect==true)
                    {
                        Eigen::Vector3d pos=grid_map.index2pos(Eigen::Vector3i(i,j,k));
                        geometry_msgs::Point p;
                        p.x=pos[0];
                        p.y=pos[1];
                        p.z=pos[2];
                        marker.points.push_back(p);
                    }
                }
            }
        }
    }
    void get_inspected_points(visualization_msgs::Marker& marker){
        // int count=0;
        for(int i=0;i<grid_map.max_index[0];i++){
            for(int j=0;j<grid_map.max_index[1];j++){
                for(int k=0;k<grid_map.max_index[2];k++){
                    if(grid_map.grid_map[i][j][k].is_inspected >=inspect_threshold && grid_map.grid_map[i][j][k].need_to_inspect==true)
                    {
                        Eigen::Vector3d pos=grid_map.index2pos(Eigen::Vector3i(i,j,k));
                        geometry_msgs::Point p;
                        p.x=pos[0];
                        p.y=pos[1];
                        p.z=pos[2];
                        marker.points.push_back(p);
                        // count++;
                    }
                }
            }
        }
        // std::cout<<count<<std::endl;
    }
    void get_search_points(visualization_msgs::Marker& marker){
        for(auto pointss:search_points_array){
            for(auto points:pointss){
                for(auto point:points){
                    if(!point.is_bad && !point.is_obstacle && !point.is_visited){
                        geometry_msgs::Point p;
                        p.x=point.pos[0];
                        p.y=point.pos[1];
                        p.z=point.pos[2];
                        marker.points.push_back(p);
                    }
                    
                }
            }
            
        }
    }

    void get_trajectory(visualization_msgs::Marker& marker){
        for(int i=0;i<_polyTime.size();i++){
            for(double t=0;t<=_polyTime[i];t+=0.1){
                try{
                    Eigen::Vector3d tmp = getPosPoly(_polyCoeff,i,t);
                    geometry_msgs::Point p;
                    p.x=tmp[0];
                    p.y=tmp[1];
                    p.z=tmp[2];
                    marker.points.push_back(p);
                }
                catch(...){}

            }
        }
    }

};


